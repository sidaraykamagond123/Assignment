
let login = (a = "CT", b = "CT") => console.log(`Username : ${a} password : ${b}`);
login("Sidaray kamagond","Sidaray1234");//When we entered the login details'a'
login('sidaray')
login();//If there are no login details it will automatically diplay the given values i.e('CT').