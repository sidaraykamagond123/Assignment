
let myFunction = (a, b) => a + b;
document.write(myFunction(3,5));